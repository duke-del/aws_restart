string="duke"
print(string)
print(string)
print (string + "is of data type " +str(type(string)))


color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")

print("{}, you like a {} {}!".format(name,color,animal))





