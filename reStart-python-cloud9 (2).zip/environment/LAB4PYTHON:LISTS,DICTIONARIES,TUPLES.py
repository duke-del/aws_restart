#LISTS,TUPLES ,DICTIONARIES
#lists
futa=["mimi","kim","alanno"]
print(futa[2
           ])
futa[2]= "mimi"
print(futa)

# TUPLE
tuple1=("orange","mango","pawpaw")
print(tuple1)
print(tuple1[0])
# Dictionaries
myFavoriteFruitDictionary ={
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(myFavoriteFruitDictionary["Akua"])