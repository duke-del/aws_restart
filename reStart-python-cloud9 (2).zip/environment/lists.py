courses=["cs","ds","it"]
print(courses)