myvalue = 34
print(myvalue)
print(type(myvalue))

print(str(myvalue) + " is of the data type " + str(type(myvalue)))


myvalue = 2.56
print(myvalue)
print(type(myvalue))

print(str(myvalue) + " is of the data type " + str(type(myvalue)))



